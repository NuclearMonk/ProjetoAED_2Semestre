#ifndef _DATA_H
#define _DATA_H
typedef void *Data;
#endif